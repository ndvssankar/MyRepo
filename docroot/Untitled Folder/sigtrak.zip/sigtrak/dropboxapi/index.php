<?php
 require 'app/start.php';
 require 'app/dropbox_auth.php';


var_dump($client->getAccountInfo());

?>
